//
//  Schedule.swift
//  
//
//  Created by Xavi Loinaz on 7/24/16.
//
//

import Foundation
